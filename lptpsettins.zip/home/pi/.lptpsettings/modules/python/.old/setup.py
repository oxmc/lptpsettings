import vlc
import subprocces
from tkinter import *

root=Tk()
"Tells the script where the harddrive is."
harddrive="/home/pi/.lptpsettings"
"Tells the script where the audio files are located."
welcome=Vlc.Mediaplayer(harddrive + "/modules/")
"Tells the script where other scripts are located."

""
