"import stuff"
from PIL import Image
import subprocess
import os
import sys
import time
from gpiozero import LED
from tkinter import *

swver="0.0.1"

root = Tk()
root.title("settings")

multicolorbacklight = LED(9)

def multicolorbacklighton():
    multicolorbacklight.on()

def multicolorbacklightoff():
   multicolorbacklight.off() 


multicolorbacklightbuttonon = Button(root, text="turn on multicolorbacklight", command=multicolorbacklighton, fg="green")
multicolorbacklightbuttonoff = Button(root, text="turn off multicolorbacklight", command=multicolorbacklightoff, fg="red")
intro = Label(text="Settings Ver. " + swver + " by seth olivarez.")

intro.grid()

multicolorbacklightbuttonon.grid()
multicolorbacklightbuttonoff.grid()
root.mainloop
