yes="yes"

read -p "Do you want to enable the rainbow backlight? " mcble

if [ "$mcble" == "$yes" ]; then

echo "okay rainbow backlight is now $mcble"

wait

clear

fi

read -p "Do you want to reboot to save changes? " rbn

if [ rbn == "yes" ]; then
sudo reboot -n