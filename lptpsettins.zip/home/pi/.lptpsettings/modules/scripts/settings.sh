#!/bin/sh
# Thanks to KenT for contributions

cd /home/pi/.lptpsettings/modules/scripts

RET=0
OPTION=$(zenity --list --width=350 --height=250  \
  --title="Settings" \
  --column="Option" "Audio output" "Background" "Force Headphones" "Force HDMI"  )
RET=$?
echo $OPTION
if [ "$OPTION" = "Audio output" ]; then
   echo "Audio output" > /home/pi/.lptpsettings/last_option.txt
   ./audiooptions.sh
elif [ "$OPTION" = "Background" ]; then
   echo "Custom Background" > /home/pi/.lptpsettings/last_option.txt
   ./Background.sh
elif [ "$OPTION" = "" ]; then
   
   echo ""
elif [ "$OPTION" = "" ]; then
   
   echo "" > /home/pi/.lptpsettings/last_option.txt
else
   echo "cancel"
fi
