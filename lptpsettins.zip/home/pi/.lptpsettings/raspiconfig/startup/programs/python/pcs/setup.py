import vlc
import subprocces
from gpiozero import LED
from tkinter import *

"Tells the script where the harddrive is."
harddrive="/home/pi/.lptpsettings/raspiconfig/startup/programs/python/pcs"
"Tells the script where the audio files are and other scripts."
startup.mp3=Vlc.Mediaplayer(harddrive + "")