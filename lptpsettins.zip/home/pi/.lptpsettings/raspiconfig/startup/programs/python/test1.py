import subprocess
subprocess.call(["/home/pi/.lptpsettings/raspiconfig/startup/programs/startup.sh"])