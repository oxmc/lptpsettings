#!/bin/bash

DIRECTORY="/home/pi/.lptpsettings"

clear

if [ -d $DIRECTORY/raspiconfig/startup ]
then
	DIRECTORY2="/home/pi/.lptpsettings/raspiconfig/startup"
	if [ -f $DIRECTORY2/newpc.txt ]
	then
		newpc=True
		echo Computer not setup. Running setup...
		python $DIRECTORY2/programs/python/pcs/setup.py

	else
	echo PC setup. Running startup programs...
	cd /home/pi/.lptpsettings/raspiconfig/startup/programs/python/pcs
	./test.sh
fi
fi