clear && echo laptop-settings ver.alpha && cd /home/pi/.lptpsettings && echo in directory .lptpsettings && echo error app not finished!
