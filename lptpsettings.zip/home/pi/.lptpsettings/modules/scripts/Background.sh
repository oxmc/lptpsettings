#!/bin/sh

if [ -f /home/pi/.lptpsettings/sbkg]; then
   CBKG="pic1.png"
   else
   echo "Done" > /tmp/temp.txt
fi

if [ -f /home/pi/.lptpsettings/modules/Custom_Backgrounds/pic1.png ]; then
   echo "files availible" > /home/pi/.lptpsettings/bgoption.txt
   else
   echo "files availible" > /home/pi/.lptpsettings/bgoption.txt
   CBKG="Unavailible"
fi

cd /home/pi/.lptpsettings/modules/scripts

RET=0
OPTION=$(zenity --list --width=420 --height=250  \
  --title="Background settings" \
  --column "Current Background:$CBKG" --column="picture name" "Selected Background: $cbkgs"  "" "$CBKG" ""  )
RET=$?
echo $OPTION
if [ "$OPTION" = "Background" ]; then
   echo "Background" > /home/pi/.lptpsettings/last_option.txt
elif [ "$OPTION" = "" ]; then
   ./settings.sh
   echo ""
elif [ "$OPTION" = "" ]; then
   ./settings.sh
   echo ""
elif [ "$OPTION" = "" ]; then
   ./settings.sh
   echo ""
else
   ./settings.sh
   echo "cancel"
fi

