#!/bin/sh
# Thanks to KenT for contribution

cd /home/pi/.lptpsettings/modules/scripts

RET=0
SOUND=$(zenity --list --width=350 --height=250 --radiolist \
  --title="Choose the Audio Output" \
  --column "Select" --column="Output" TRUE "Leave as is" FALSE "Auto" FALSE "Force Headphones" FALSE "Force HDMI"  )
RET=$?
echo $SOUND
if [ "$SOUND" = "Leave as is" ]; then
   echo "Leaving audio output as is" > /home/pi/.lptpsettings/Selected_Audio_Output.txt
elif [ "$SOUND" = "Auto" ]; then
   amixer -c 0 cset numid=3 0
   echo "Automaticly set audio output." > /home/pi/.lptpsettings/Selected_Audio_Output.txt
elif [ "$SOUND" = "Force Headphones" ]; then
   amixer -c 0 cset numid=3 1
   echo "Headphones set as audio output." > /home/pi/.lptpsettings/Selected_Audio_Output.txt
elif [ "$SOUND" = "Force HDMI" ]; then
   amixer -c 0 cset numid=3 2
   echo "HDMI set as audio output." > /home/pi/.lptpsettings/Selected_Audio_Output.txt
else
   echo "cancel"
   ./settings.sh
fi
