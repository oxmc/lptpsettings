import pygame, sys
from pygame.locals import *

Dir = "/home/pi/.lptpsettings"

pygame.init()

FPS = 30 # frames per second setting
fpsClock = pygame.time.Clock()

# set up the window
pygame.display.set_caption("Settings")
DISPLAYSURF = pygame.display.set_mode((400, 300), 0, 32)

WHITE = (255, 255, 255)
logoImg = pygame.image.load(Dir + '/icons/logo.png')
logox = 10
logoy = 10

while True: # the main game loop
    DISPLAYSURF.fill(WHITE)

    DISPLAYSURF.blit(logoImg, (logox, logoy))
    
    menuAtivo = True;

start_button = pygame.draw.rect(screen,(0,0,240),(150,70,100,50));
continue_button = pygame.draw.rect(screen,(0,244,0),(150,160,100,50));
quit_button = pygame.draw.rect(screen,(244,0,0),(150,230,100,50));


pygame.display.flip();


while menuAtivo:
    for evento in pygame.event.get():
     print(evento);
    if evento.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_pos() >= (150,230):
                    if pygame.mouse.get_pos() <= (195,113):

    



		     pygame.display.update()
		     fpsClock.tick(FPS)
