import subprocess
import sys
subprocess.Popen([sys.executable, "/home/pi/.lptpsettings/settings-gui-version.py"])